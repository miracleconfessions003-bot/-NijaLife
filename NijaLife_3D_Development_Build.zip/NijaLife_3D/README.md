# NijaLife 3D — Development Build

This is a genuine browser-based 3D development build using Three.js. It includes a third-person camera, a 3D neighbourhood, simple 3D characters, appearance controls, movement, NPC wandering, Nigerian city selection, and simulated life actions (bathing, toilet, cooking, garri, eating, sleep, work and conversations).

## Play locally

Requires internet to load the Three.js module from jsDelivr. Serve this folder over HTTP (not `file://`):

```bash
npm install
npm start
```
Then open `http://localhost:3000`.

## Deploy

This repo is prepared for a Render Docker web service via `render.yaml`. Push the project folder to a GitHub repository and create a Render Blueprint from it. Hosting may require a paid plan. The deployed web service will provide a public browser link, but this build does NOT yet have a persistent database, real accounts, moderation, or live multiplayer. Game money and needs are simulated and reset on refresh. It is not a finished commercial game and the graphics are stylized 3D, not photorealistic.

## Controls

- Keyboard: WASD or arrow keys
- Mobile: on-screen direction pad
- Tap Character to customize skin, hair, face, clothes, body and city
- Tap actions to trigger daily-life interactions

## Important

This build is a playable 3D development build, not a completed AAA game. A public deployment requires hosting-account access and an actual deployment. No live public server is claimed by this package.
